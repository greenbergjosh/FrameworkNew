﻿namespace Framework.Core.Evaluatable
{
    public delegate Task<Entity.Entity> EvalProvider(Entity.Entity providerParameters, Entity.Entity request);
}
