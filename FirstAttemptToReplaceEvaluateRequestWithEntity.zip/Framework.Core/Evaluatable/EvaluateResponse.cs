﻿namespace Framework.Core.Evaluatable
{
    public record EvaluateResponse(bool Complete, Entity.Entity Entity);
}
