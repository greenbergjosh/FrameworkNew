﻿using Framework.Core.Entity;
using Framework.Core.Entity.Implementations;

namespace Framework.Core.Evaluatable.EvalProviders
{
    public static class PfaEvalProvider
    {
        public static string Name => "Pfa";

        // The Pfa provider expects two parameters:
        // entity: The entity that will be evaluated
        // parameters: The (potentially partially applied) parameters to pass to `entity`
        public static async Task<Entity.Entity> Evaluate(Entity.Entity providerParameters, Entity.Entity request)
        {
            var entity = await providerParameters.Document.GetRequiredProperty("entity");
            var entityParameters = await providerParameters.GetRequiredProperty("parameters", request);

            if (request.Document is not EntityDocumentStack stack)
            {
                stack = new EntityDocumentStack();
                if (request.ValueType != EntityValueType.Undefined)
                {
                    stack.Push(request.Document);
                }
            }

            stack.Push(entityParameters.Document);

            var result = await entity.Evaluate(entity.Create(stack));

            _ = stack.Pop();

            return result;
        }
    }
}
