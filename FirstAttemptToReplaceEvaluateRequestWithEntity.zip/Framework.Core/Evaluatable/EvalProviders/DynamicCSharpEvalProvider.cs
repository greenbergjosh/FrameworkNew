﻿using Framework.Core.Entity;

namespace Framework.Core.Evaluatable.EvalProviders
{
    public class DynamicCSharpEvalProvider
    {
        public static string Name => "DynamicCSharp";

        private readonly RoslynWrapper<Entity.Entity, Entity.Entity> _roslyn;

        public DynamicCSharpEvalProvider(RoslynWrapper<Entity.Entity, Entity.Entity> roslyn) => _roslyn = roslyn;

        public async Task<Entity.Entity> Evaluate(Entity.Entity providerParameters, Entity.Entity request)
        {
            var code = await providerParameters.GetRequiredString("code");
            return await _roslyn.Evaluate(code, request);
        }
    }
}
