﻿using Framework.Core.Entity;

namespace Framework.Core.Evaluatable.EvalProviders
{
    public static class ERefEvalProvider
    {
        public static string Name => "ERef";

        public static async Task<Entity.Entity> Evaluate(Entity.Entity providerParameters, Entity.Entity request)
        {
            var url = await providerParameters.GetRequiredString("url", request);

            if (!Uri.TryCreate(url, UriKind.Absolute, out var uri))
            {
                throw new InvalidOperationException("`url` must be a valid URI");
            }

            var resolvedEntity = await providerParameters.ResolveEntity(uri);

            var quoted = await providerParameters.GetOrDefault<bool>("quoted");
            if (quoted)
            {
                return request.Create(new
                {
                    Completed = true,
                    Result = resolvedEntity
                });
            }

            return await resolvedEntity.Evaluate(request);
        }
    }
}
